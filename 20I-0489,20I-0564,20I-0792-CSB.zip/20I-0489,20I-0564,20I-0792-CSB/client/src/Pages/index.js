//IMPORTING LIBRARIES   [STEP-1]
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require("dotenv");
const multer = require("multer");
const helmet = require("helmet");
const morgan = require("morgan");
const path = require("path");


//USING CONFIGURATION FILE  [STEP-2]
dotenv.config();

//||||||||||||||||||||||||||||||||||||||||||||||||EXPRESS SETUP [USE EXPRESS REPOSITORY]
const app = express();
app.use(express.json());

//||||||||||||||||||||||||||||||||||||||||||||||||HELMET SETUP  [USE HELMET REPOSITORY]
app.use(helmet());
app.use(helmet.crossOriginResourcePolicy({ policy:"cross-origin"}));

//||||||||||||||||||||||||||||||||||||||||||||||||MORGON SETUP  [USE MORGON REPOSITORY]
app.use(morgan("common"));

//||||||||||||||||||||||||||||||||||||||||||||||||BODYPARSER SETUP [USE BP REPOSITORY]
app.use(bodyParser.json( {limit:"30mb",extended:true} ));
app.use(bodyParser.urlencoded( {limit:"30mb",extended:true} ))

//||||||||||||||||||||||||||||||||||||||||||||||||CORS SETUP [USE CORS REPOSITORY]
app.use(cors());

//STORES OUR STATIC FILES, WE ARE GIVING PATH TO IT [LOCAL STORAGE]
app.use('./assets',express.static(path.join(__dirname,'public/assets')));

//||||||||||||||||||||||||||||||||||||||||||||||||MULTER SETUP [USE MULTER REPOSITORY]
const Storage = multer.diskStorage( 
    {
        destination: function(Request,File,Cb)
        {
            Cb(null,"public/assets");
        },
        filename: function (Request,File,Cb)
        {
            Cb(null,File.originalname);    
        }
    }
) //This function is used to choose the location of where the files from our web application will be stored. 

const upload = multer({Storage});  //This variable will allow us to use the local storage.

//////////////////////////////////////////////////

//import {Register} from "./controllers/auth.js"
//app.post("/auth/register", upload.single("picture") , Register);
app.use ( '/', require(path.join(__dirname , './controllers/auth')))

//MONGOOSE-SETUP[STEP-3]
//SETUP .env file first.

const PORT_NUMBER = 4001;
mongoose.connect('mongodb+srv://salissalman1:Salis2002$@cluster0.avsodow.mongodb.net/?retryWrites=true&w=majority',
    {
      useNewUrlParser : true,
      useUnifiedTopology: true,  
    }).then(
    ()=>
    {
        app.listen(PORT_NUMBER,()=>{console.log(`SERVER IS LISTENING AT ${PORT_NUMBER}`)});
    }
).catch((error)=>{console.log(`SORRY, WE COULDD'T CONNECT YOU TO SERVER ${error}`)});



/////////////////////////////////////////////////////////////////////////////CREATING REGISTERATION [STEP-5] /////////////////////////////
const Register = require("./controllers/auth")
app.post("/auth/register", upload.single("picture") , Register);


///////////////////////////////////////////////////////////////////////////// ROUTING PATH [STEP-6] /////////////////////////////
const AuthRoutes = require("./routes/auth.js");
app.use('/auth',AuthRoutes);

///////////////////////////////////////////////////////////////////////////// STEPS FOR USER PROFILE [STEP-7] /////////////////////////////

const ProfileRoutes = require("./routes/Profile.js");
app.use('/User',ProfileRoutes);

///////////////////////////////////////////////////////////////////////////// STEPS FOR POSTS PROFILE [STEP-8] /////////////////////////////

const PostRoutes = require("./routes/Posts.js");
const CreatePost = require("./PostFunctions/CreatePost")
const VarifyToken = require('./Middleware/Auth');
app.use('/Posts',PostRoutes);
app.post("/Posts",VarifyToken, upload.single("picture"),CreatePost);



