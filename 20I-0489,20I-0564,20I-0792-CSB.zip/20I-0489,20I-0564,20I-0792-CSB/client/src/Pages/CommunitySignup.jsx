import { Box } from "@mui/material";
import { Button} from "@mui/material";
import { TextField } from "@mui/material";
import { Link } from 'react-router-dom';
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material";
import { Formik } from "formik";
import * as Veteran from "yup";
import { useNavigate } from "react-router-dom";
import {useCommunitySignupMutation} from "../Services/NodeApi.js"


const Form = () => 
{
   const [ communitySignup ]=useCommunitySignupMutation();
      
    const InsertCommunity = async (values, onSubmitProps) => 
    {
      const res=await communitySignup( values )
     
      if (res) 
      {
        navigate("/CommunityLogin");
      }
    };
    
  const { palette } = useTheme();
  const navigate = useNavigate();
  
  const CreateVeteran = async (values, onSubmitProps) => { await InsertCommunity(values, onSubmitProps) };

  return (
    <Box>
      <Box padding="1vw" backgroundColor={"#1A1A1A"} textAlign="center" >
        <Typography color="primary" fontWeight="bold" fontSize="32px"> VetranMeet </Typography>
      </Box>
      <Typography color="primary" fontWeight="bold" fontSize="32px" textAlign={"center"} marginTop="4vw"> Create Community Account </Typography>
      <Typography color="primary" fontWeight="700px" fontSize="20px" marginLeft={"36vw"} marginTop="1vw" marginBotton="1vw"> Enter Account Information </Typography>

      <Formik  onSubmit={CreateVeteran} initialValues= {CommunityValues} validationSchema = {CommunityRegisteration}  >
      {({ handleChange, handleSubmit, values }) => 
      (
        <form onSubmit={handleSubmit}>
          <Box display="grid" gap="10px" gridTemplateColumns="1fr" marginLeft={"36vw"} width="400px" marginTop="1vw" >
            <TextField name="name"      label="Organization Name"                       onChange={handleChange} value={values.name} marginRight="1vw"/>
            <TextField name="type"      label="Type [NGO,Organization,Community] Name"  onChange={handleChange} value={values.type} marginLeft="1vw" />
            <TextField name="email"     label="Email"                                   onChange={handleChange} value={values.email} sx={{ gridColumn: "span 2" }}/>
            <TextField name="password"  label="Password"                                onChange={handleChange} value={values.password}  type="password" sx={{ gridColumn: "span 2" }}/>
            <TextField name="phone"     label="Contact"                                 onChange={handleChange} value={values.phone}/>
            <TextField name="city"      label="City"                                    onChange={handleChange} value={values.city} />  
        </Box>
        <Box marginLeft={"36vw"} marginTop={"2vw"} width="26vw">          
        <Button fullWidth type="submit" padding= "2rem" marginTop="1rem" sx={{ backgroundColor: palette.primary.main, color: palette.background.alt,  "&:hover": { color: palette.primary.main }, }}> Create Orgnization </Button>
        <Box marginTop={"2vw"} width="30vw">          
            <Typography marginLeft={"2.5vw"} color={"#6bd5fa"}><Link to="/OrganizationSignIn"> Login as Organization</Link>  <a style={{marginLeft:"1rem"}} href={" "} >OR</a>   <Link to="/UserSignIn" style={{marginLeft:"1rem"}}> Login as Veteran</Link> </Typography>
        </Box>
        </Box>
        </form>
      )}
    </Formik>
  </Box>
  );
};
const CommunityRegisteration = Veteran.object().shape(
{
    name: Veteran.string().required("required"),
    email: Veteran.string().email("invalid email").required("required"),
    password: Veteran.string().required("required"),
    type: Veteran.string().required("required"),
    phone: Veteran.string().required("required"),
    city: Veteran.string().required("required"),
});


const CommunityValues = 
{
    name : "",
    email : "",
    password : "",
    type : "",
    phone : "",
    city : ""
};
    
export default Form;
