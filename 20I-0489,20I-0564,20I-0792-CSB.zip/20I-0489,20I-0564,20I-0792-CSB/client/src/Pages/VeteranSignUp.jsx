import { Box } from "@mui/material";
import { Button} from "@mui/material";
import { TextField } from "@mui/material";
import { Link } from 'react-router-dom';
import { Typography } from "@mui/material";
import { useTheme } from "@mui/material";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import { Formik } from "formik";
import * as Veteran from "yup";
import { useNavigate } from "react-router-dom";
import Dropzone from "react-dropzone";

const Form = () => 
{
  const InsertVeteran = async (values, onSubmitProps) => 
  {
    const DataEntered = new FormData();
    for (let value in values) {
        DataEntered.append(value, values[value]);
    }
    DataEntered.append("picturePath", values.picture.name);

    const InsertData = await fetch(
      "http://localhost:3001/auth/register",
      {
        method: "POST",
        body: DataEntered,
      }
    );
    const AddStatus = await InsertData.json();
    onSubmitProps.resetForm();

    if (AddStatus) 
    {
      navigate("/UserSignIn");
    }
  };

  const { palette } = useTheme();
  const navigate = useNavigate();
  
  const CreateVeteran = async (values, onSubmitProps) => { await InsertVeteran(values, onSubmitProps) };

  return (
    <Box>
      <Box padding="1vw" backgroundColor={"#1A1A1A"} textAlign="center" >
        <Typography color="primary" fontWeight="bold" fontSize="32px"> VetranMeet </Typography>
      </Box>
      <Typography color="primary" fontWeight="bold" fontSize="32px" textAlign={"center"} marginTop="4vw"> Create Veteran Account </Typography>
      <Typography color="primary" fontWeight="700px" fontSize="20px" marginLeft={"36vw"} marginTop="1vw" marginBotton="1vw"> Enter Account Information </Typography>

      <Formik  onSubmit={CreateVeteran} initialValues= {VeteranValues} validationSchema = {VeteranRegisteration}  >
      {({ handleChange, handleSubmit, values, setFieldValue }) => 
      (
        <form onSubmit={handleSubmit}>
         
          <Box display="grid" gap="10px" gridTemplateColumns="1fr" marginLeft={"36vw"} width="400px" marginTop="1vw" >
            <TextField name="firstName" label="First Name" onChange={handleChange} value={values.firstName} marginRight="1vw"/>
            <TextField name="lastName"  label="Last Name"  onChange={handleChange} value={values.lastName} marginLeft="1vw" />
            <TextField name="email"     label="Email"      onChange={handleChange} value={values.email} sx={{ gridColumn: "span 2" }}/>
            <TextField name="password"  label="Password"   onChange={handleChange} value={values.password}  type="password" sx={{ gridColumn: "span 2" }}/>
            <TextField name="location"  label="City"       onChange={handleChange} value={values.location} />  
            <TextField name="occupation"     label="Hobby"      onChange={handleChange} value={values.occupation}/>
            <Dropzone  acceptedFiles=".jpg,.jpeg,.png"  multiple={false} onDrop={(acceptedFiles) => setFieldValue("picture", acceptedFiles[0]) }>
                    {({ getRootProps, getInputProps }) => (
                      <Box {...getRootProps()} border={`2px solid ${palette.primary.main}`} p="0.25rem" textAlign="center" sx={{ gridColumn: "span 2" }}>
                        <input {...getInputProps()} />
                        {!values.picture ? (
                          <p>Browse Profile Picture</p>
                        ) : 
                        (
                          <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center",}}>
                            <Typography>{values.picture.name}</Typography>
                            <EditOutlinedIcon />
                          </Box>
                        )}
                      </Box>
                    )}
            </Dropzone>
        </Box>
        <Box marginLeft={"36vw"} marginTop={"2vw"} width="26vw">          
        <Button fullWidth type="submit" padding= "2rem" marginTop="1rem" sx={{ backgroundColor: palette.primary.main, color: palette.background.alt,  "&:hover": { color: palette.primary.main }, }}> Create Account </Button>
          <Box marginTop={"2vw"} width="30vw">          
              <Typography marginLeft={"2.5vw"} color={"#6bd5fa"}><Link to="/OrganizationSignIn"> Login as Organization</Link>  <a style={{marginLeft:"1rem"}} href={" "} >OR</a>   <Link to="/UserSignIn" style={{marginLeft:"1rem"}}> Login as Veteran</Link> </Typography>
          </Box>
        </Box>
        </form>
      )}
    </Formik>
  </Box>
  );
};
const VeteranRegisteration = Veteran.object().shape(
{
    firstName: Veteran.string().required("required"),
    lastName: Veteran.string().required("required"),
    email: Veteran.string().email("invalid email").required("required"),
    password: Veteran.string().required("required"),
    location: Veteran.string().required("required"),
    occupation: Veteran.string().required("required"),
    picture: Veteran.string().required("required"),
});


const VeteranValues = 
{
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    location: "",
    occupation: "",
    picture: "",
};
    
export default Form;
