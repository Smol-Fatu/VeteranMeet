import { Box , Button, TextField, Typography, useTheme} from "@mui/material";
import { setLogin } from "state";
import { Link } from 'react-router-dom';
import { Formik } from "formik";
import * as Veteran from "yup";
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";


const VeteranSchema = Veteran.object().shape(
{
    email: Veteran.string().email("invalid email").required("required"),
    password: Veteran.string().required("required"),
});

const VeteranValidations = 
{
  email: "",
  password: "",
};

const Form = () => 
{
    const VeteranLogin = async (values, onSubmitProps) => 
    {
        const loggedInResponse = await fetch("http://localhost:3001/auth/login", 
        {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(values),
        });
        const loggedIn = await loggedInResponse.json();
        onSubmitProps.resetForm();
        if (loggedIn) {
            dispatch(
            setLogin({
                user: loggedIn.user,
                token: loggedIn.token,
            })
            );
            navigate("/home");
        }
    };
    
    const { palette } = useTheme();
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const LoginPressed = async (values, onSubmitProps) => 
    {
        await VeteranLogin(values, onSubmitProps);
    };

  return (
    <Box>
      <Box padding="1vw" backgroundColor={"#1A1A1A"} textAlign="center" >
        <Typography color="primary" fontWeight="bold" fontSize="32px"> VetranMeet </Typography>
      </Box>
      <Typography color="primary" fontWeight="bold" fontSize="32px" textAlign={"center"} marginTop="4vw"> Welcome Veteran </Typography>

      <Formik  onSubmit={LoginPressed} initialValues= {VeteranValidations} validationSchema = {VeteranSchema}  >
      {({ handleChange, handleSubmit, resetForm, values, errors,touched }) => 
      (
        <form onSubmit={handleSubmit}>
          <Box display="grid" gap="30px" gridTemplateColumns="8" marginLeft={"36vw"} marginTop={"4vw"} width="30vw" >
            <TextField name="email"    label="Email"    onChange={handleChange} value={values.email}  />
            <TextField name="password" label="Password" onChange={handleChange} value={values.password}  type="password"/>
          </Box>

          <Box marginLeft={"36vw"} marginTop={"2vw"} width="30vw">          
            <Button fullWidth type="submit" padding= "2rem" marginTop="1rem" sx={{ backgroundColor: palette.primary.main, color: palette.background.alt,  "&:hover": { color: palette.primary.main }, }}> Login </Button>
            <Box marginTop={"2vw"} width="30vw">          
             <Typography marginLeft="2rem" color={"#6bd5fa"}><Link to="/OrganizationSignUp"> Create Organization Account</Link>  <a style={{marginLeft:"1.5rem"}} href={" "} >OR</a>   <Link to="/UserSignUp" style={{marginLeft:"1.5rem"}}> Create Veteran Account</Link> </Typography>
           </Box>
          </Box>
        </form>
      )}
    </Formik>
  </Box>
  );
};

export default Form;
