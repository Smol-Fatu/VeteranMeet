import { Box } from "@mui/material";
import { useSelector } from "react-redux";
import NavigationBar from "Reusables/Header";
import MyPostWidget from "scenes/widgets/MyPostWidget";
import PostsWidget from "scenes/widgets/PostsWidget";
import FriendListWidget from "scenes/widgets/FriendListWidget";
import { styled } from "@mui/system";
import { ManageAccountsOutlined, LocationOnOutlined,  WorkOutlineOutlined  } from "@mui/icons-material";
import { Typography, Divider, useTheme } from "@mui/material";


import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
  

const HomePage = () => {
  const { _id, picturePath } = useSelector((state) => state.user);

  return (
    <Box>
      <NavigationBar></NavigationBar>
      <Box width="100%" padding="2rem 6%" display={ "flex" } gap="0.5rem" justifyContent="space-between" >
            <Box flexBasis={"26%"}>
               <UserWidget userId={_id} picturePath={picturePath} />
            </Box>
            <Box flexBasis={"42%" } mt={undefined }>
               <MyPostWidget picturePath={picturePath} />
               <PostsWidget userId={_id} />
        </Box>
        <Box flexBasis="26%">
            <FriendListWidget userId={_id} />
        </Box>
      </Box>
    </Box>    
  );
};


// eslint-disable-next-line no-unused-vars
const MainDashboard = styled(Box)(({ theme }) => ({ width:"100%" ,  padding:"2rem 6%" ,display: "flex" , gap:"0.5rem", justifyContent:"space-between"}));

const UserWidget = ({ userId, picturePath }) => 
{
    const [user, setUser] = useState(null);
    const { palette } = useTheme();
    const navigate = useNavigate();
    const token = useSelector((state) => state.token);
    const medium = palette.neutral.medium;
    const main = palette.neutral.main;

    const ExtractUser = async () => 
    {
        const Response = await fetch(`http://localhost:3001/users/${userId}`, 
        {
        method: "GET",
        headers: { Authorization: `Bearer ${token}` },
        });
        const Data = await Response.json();
        setUser(Data);
    };

    useEffect(() => {
        ExtractUser();
    }, []); 

    if (!user) 
    {
        return null;
    }

    const 
    { firstName, lastName, location, occupation, stars, friends } = user;

    const DisplayName = `${firstName} ${lastName}`;
    const City = location;
    const Hobby = occupation;
    const Stars = stars;
    const NumberOfFriends = friends.length;
    return (
        <PROFILE_VIEW>
        <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center" , pb: "1.1rem"}} onClick={() => navigate(`/profile/${userId}`)} gap="0.5rem"  >
            <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", gap:"1rem"}}>
            <PROFILE_VIEW image={picturePath} />
            <Box>
                <Typography fontSize={"20px"} color={"#333333"} fontWeight="bold" >
                {DisplayName}
                </Typography>
                <Typography color={"#333333"}>{NumberOfFriends} Friends</Typography>
            </Box>
            </Box>
            <ManageAccountsOutlined />
        </Box>

        <Divider />

        <Box padding="1rem">
            <Box display="flex" alignItems="center" gap="1rem" marginBottom={"0.5rem"}>
            <LocationOnOutlined fontSize="large" sx={{ color:"#00D5FA" }} />
            <Typography color={"#333333"}> City : {City}</Typography>
            </Box>
            <Box display="flex" alignItems="center" gap="1rem">
            <WorkOutlineOutlined fontSize="large" sx={{ color: "#00D5FA" }} />
            <Typography color={medium}> Hobby : {Hobby}</Typography>
            </Box>
        </Box>

        <Divider />
        <Box p="1rem 0">
           <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", mb:"0.5rem"}}>
            <Typography color={main} fontWeight="500">
                STARS : {Stars} ✩
            </Typography>
            </Box>
        </Box>
        </PROFILE_VIEW>
    );
};


const PROFILE_VIEW = styled(Box)(({ theme }) => ({
    padding: "1.5rem 1.5rem 0.75rem 1.5rem",
    backgroundColor: theme.palette.background.alt,
    borderRadius: "0.75rem",
}));
  
export default HomePage;
