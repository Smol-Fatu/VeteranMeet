
export const themes = (mode) => {
  return {
    palette: {
      mode: mode,
            primary: {
              dark: "#006B7D",
              main: "#00D5FA",
              light: "#2f5cc4",
            },
            neutral: {
              dark: "#333333",
              main: "#666666",
              light:"#F0F0F0",
            },
            background: {
              default: "#F6F6F6",
              alt: "#FFFFFF",
            },
    },
    typography: {
      fontFamily: "Nunito",
      fontSize: 12,
      h1: {
        fontFamily: "Nunito",
        fontSize: 40,
      },
      h2: {
        fontFamily: "Nunito",
        fontSize: 32,
      },
      h3: {
        fontFamily: "Nunito",
        fontSize: 24,
      },
      h4: {
        fontFamily: "Nunito",
        fontSize: 20,
      },
      h5: {
        fontFamily:"Nunito",
        fontSize: 16,
      },
      h6: {
        fontFamily:"Nunito",
        fontSize: 14,
      },
    },
  };
};
