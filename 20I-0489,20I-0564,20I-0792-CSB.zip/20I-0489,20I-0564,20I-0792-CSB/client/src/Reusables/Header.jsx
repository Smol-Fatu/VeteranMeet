import { IconButton } from "@mui/material";
import { InputBase } from "@mui/material";
import { Typography } from "@mui/material";
import { Select } from "@mui/material";
import { Box } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { MenuItem } from "@mui/material";
import { FormControl } from "@mui/material";
import { useTheme } from "@mui/material";
import { Search, Message ,Notifications} from "@mui/icons-material";
import { useSelector } from "react-redux";
import { Link } from 'react-router-dom';

const Navbar = () => 
{
  const navigate = useNavigate();
  const user = useSelector((state) => state.user);
  const theme = useTheme();
  const neutralLight = theme.palette.neutral.light;

  const DisplayName = `${user.firstName} ${user.lastName}`;  
  return (
    <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center" , padding:"1rem 6%" , backgroundColor:"#FFFFFF"}}>
      <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center" , gap:"12rem"}}>
        <Typography fontWeight="bold" fontSize="30px" color="primary" onClick={() => navigate("/home")} > VeteranMeet </Typography>
          <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center" , backgroundColor:{neutralLight} , borderRadius:"3px" ,gap:"4rem", padding:"0.25rem 1rem", marginLeft:"2vw"}}>
            <InputBase placeholder="Search" />
            <IconButton>
              <Search />
            </IconButton>
          </Box>
      </Box>
      <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center" ,gap:"2rem" }}>
         <Box sx={{display: "flex",justifyContent: "space-between",alignItems: "center" ,gap: "1rem"}}>
                <FormControl variant="standard" value={DisplayName}>
                    <Select value={DisplayName}
                    sx={{ backgroundColor: neutralLight, width: "150px", borderRadius: "0.25rem", padding: "0.25rem 1rem", "& .MuiSvgIcon-root": {pr: "0.25rem",width: "3rem",}, "& .MuiSelect-select:focus": { backgroundColor: neutralLight,},}}
                    input={<InputBase />}
                    >
                    <MenuItem value={DisplayName}>
                            <Typography>{DisplayName}</Typography>
                    </MenuItem>
                    <MenuItem><Link to="/"> LogOut</Link>
                    </MenuItem>
                    </Select>
                </FormControl>
            </Box>
                <Message       sx={{ fontSize: "25px" }} />
                <Notifications sx={{ fontSize: "25px" }} />
        </Box>
    </Box>
  );
};

export default Navbar;
