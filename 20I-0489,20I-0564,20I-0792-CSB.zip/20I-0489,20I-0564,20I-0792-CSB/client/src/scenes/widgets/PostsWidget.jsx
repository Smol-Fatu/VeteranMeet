import { useState } from "react";
import { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Box, Divider, IconButton, Typography } from "@mui/material";
import Friend from "components/Friend"
import { setPosts } from "state";
import { setPost } from "state";
import {ChatBubbleOutlineOutlined, FavoriteBorderOutlined, FavoriteOutlined } from "@mui/icons-material";


const PostsWidget = ({ userId, isProfile = false }) => 
{
  const ExtractAllPosts = async () => 
  {
    const ApiResponse = await fetch("http://localhost:3001/posts", {
      method: "GET",
      headers: { Authorization: `Bearer ${SecurityTokens}` },
    });
    const ApiReturn = await ApiResponse.json();
    dispatch(setPosts({ posts: ApiReturn}));
  };

  const ExtraxtUserPosts = async () => 
  {
    const ApiResponse = await fetch(
      `http://localhost:3001/posts/${userId}/posts`,
      {
        method: "GET",
        headers: { Authorization: `Bearer ${SecurityTokens}` },
      }
    );
    const ApiReturn = await ApiResponse.json();
    dispatch(setPosts({ posts: ApiReturn }));
  };

  const dispatch = useDispatch();
  const Posts = useSelector((state) => state.posts);
  const SecurityTokens = useSelector((state) => state.token);


  useEffect(() => 
  {
    if (isProfile) 
    {
        ExtraxtUserPosts();
    } 
    else 
    {
        ExtractAllPosts();
    }
  }, []); 

  return (
    <>
      {Posts.map(
        ({ _id,  userId, firstName, lastName, description, location, picturePath, userPicturePath,likes,comments,}) => 
        (
         <DisplayPosts key={_id} postId={_id} postUserId={userId} name={`${firstName} ${lastName}`} description={description} location={location} picturePath={picturePath} userPicturePath={userPicturePath} likes={likes}comments={comments}/>
        )
      )}
    </>
  );
};

export default PostsWidget;



const DisplayPosts = ({ postId,postUserId, name, description, location, picturePath, userPicturePath, likes, comments,}) => 
{
  const dispatch = useDispatch();
  const token = useSelector((state) => state.token);
  const loggedInUserId = useSelector((state) => state.user._id);
  const isLiked = Boolean(likes[loggedInUserId]);
  const likeCount = Object.keys(likes).length;
  const [isComments, setIsComments] = useState(false);

  const GetPostLikes = async () => {
    const ApiResponse = await fetch(`http://localhost:3001/posts/${postId}/like`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ userId: loggedInUserId }),
    });
    const LikeIncreased = await ApiResponse.json();
    dispatch(setPost({ post: LikeIncreased }));
  };

  return (
    <Box sx={{  padding: "1.5rem 1.5rem 0.75rem 1.5rem", backgroundColor:"#FFFFFF",borderRadius: "0.75rem" , m:"2rem 0"}}>
      <Friend friendId={postUserId} name={name} subtitle={location} userPicturePath={userPicturePath} />
      <Typography color={"#00D5FA"} sx={{ mt: "1rem" }}>
        {description}
      </Typography>
      {picturePath && ( <img width="100%"  height="auto"  alt="post" style={{ borderRadius: "0.75rem", marginTop: "0.75rem" }} src={`http://localhost:3001/assets/${picturePath}`} />)}
      <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", mt:"0.25rem"}}>
        <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", gap:"1rem"}}>
         <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", gap:"0.3rem"}}>
            <IconButton onClick={GetPostLikes}>
              {isLiked ? ( <FavoriteOutlined sx={{ color: "#2f5cc4" }} />) : (<FavoriteBorderOutlined />)}
            </IconButton>
            <Typography>{likeCount}</Typography>
          </Box>

        <Box sx={{ display: "flex",justifyContent: "space-between",alignItems: "center", gap:"0.3rem"}}>
            <IconButton onClick={() => setIsComments(!isComments)}>
              <ChatBubbleOutlineOutlined />
            </IconButton>
            <Typography>{comments.length}</Typography>
          </Box>
        </Box>
      </Box>
      {isComments && (
        <Box mt="0.5rem">
          {comments.map((comment, i) => (
            <Box key={`${name}-${i}`}>
              <Divider />
              <Typography sx={{ color: "#00D5FA", m: "0.5rem 0", pl: "1rem" }}>
                {comment}
              </Typography>
            </Box>
          ))}
          <Divider />
        </Box>
      )}
    </Box>
  );
};
