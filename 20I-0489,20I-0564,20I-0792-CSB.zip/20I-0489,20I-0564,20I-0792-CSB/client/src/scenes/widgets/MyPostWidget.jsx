import {  EditOutlined, DeleteOutlined, ImageOutlined } from "@mui/icons-material";
import {  Box, Divider, Typography, InputBase, Button, IconButton,} from "@mui/material";
import Dropzone from "react-dropzone";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setPosts } from "state";

const CreateVeteranPost = ({ picturePath }) => {
  const dispatch = useDispatch();
  const [isImage, setIsImage] = useState(false);
  const [image, setImage] = useState(null);
  const [post, setPost] = useState("");
  const { _id } = useSelector((state) => state.user);
  const token = useSelector((state) => state.token);


  const CreatePost = async () => 
  {
     const AddPost = new FormData();
     AddPost.append("userId", _id);
     AddPost.append("description", post);
     if (image) 
     {
      AddPost.append("picture", image);
      AddPost.append("picturePath", image.name);
    }

    const response = await fetch(`http://localhost:3001/posts`, 
    {
      method: "POST",
      headers: { Authorization: `Bearer ${token}` },
      body: AddPost,
    });
    const posts = await response.json();
    dispatch(setPosts({ posts }));
    setImage(null);
    setPost("");
  };

  return (
    <Box sx={{  padding: "1.5rem 1.5rem 0.75rem 1.5rem", backgroundColor: "#FFFFFF", borderRadius: "0.75rem", }}>
      <Box sx={{display: "flex",  justifyContent: "space-between" , alignItems: "center" , gap:"1.5rem"}}>
        <UserImage image={picturePath} />
        <InputBase placeholder="What's on your mind?" onChange={(e) => setPost(e.target.value)}value={post} sx={{
            width: "100%",
            backgroundColor: "#F0F0F0",
            borderRadius: "1rem",
            padding: "0.75rem 2rem",
          }}
        />
      </Box>
      {isImage && (
        <Box
          border={`1px solid ${"#666666"}`}
          borderRadius="5px"
          mt="1rem"
          p="1rem"
        >
          <Dropzone
            acceptedFiles=".jpg,.jpeg,.png"
            multiple={false}
            onDrop={(acceptedFiles) => setImage(acceptedFiles[0])}
          >
            {({ getRootProps, getInputProps }) => (
            <Box sx={{display: "flex",  justifyContent: "space-between" , alignItems: "center" }}>
              <Box {...getRootProps()}  width="100%" border={`2px solid ${"#00D5FA"}`} p="0.25rem" textAlign="center" >
                  <input {...getInputProps()} />
                  {!image ? (
                    <p>Add Image Here</p>
                  ) : ( 
                    <Box sx={{display: "flex",  justifyContent: "space-between" , alignItems: "center"}}>
                    <Typography>{image.name}</Typography>
                      <EditOutlined />
                    </Box>
                  )}
                </Box>
                {image && (<IconButton onClick={() => setImage(null)} sx={{ width: "15%" }} ><DeleteOutlined /></IconButton>)}
              </Box>
            )}
          </Dropzone>
        </Box>
      )}
      <Divider sx={{ margin: "1.25rem 0" }} />
      <Box sx={{display: "flex",  justifyContent: "space-between" , alignItems: "center"}}>
        <Box sx={{display: "flex",  justifyContent: "space-between" , alignItems: "center" , gap:"0.25rem"}} onClick={() => setIsImage(!isImage)}>
          <ImageOutlined sx={{ color:"#666666" }} />
          <Typography color={"#666666"}> Add Image</Typography>
        </Box>
        <Button disabled={!post} onClick={CreatePost}  sx={{  backgroundColor: "#00D5FA",  borderRadius: "1rem", color: "#FFFFFF" }}>  POST
        </Button>
      </Box>
    </Box>
  );
};


const UserImage = ({ image, size = "60px" }) => {
  return (
    <Box width={size} height={size}>
      <img
        style={{ objectFit: "cover", borderRadius: "50%" }}
        width={size}
        height={size}
        alt="user"
        src={`http://localhost:3001/assets/${image}`}
      />
    </Box>
  );
};

export default CreateVeteranPost;

