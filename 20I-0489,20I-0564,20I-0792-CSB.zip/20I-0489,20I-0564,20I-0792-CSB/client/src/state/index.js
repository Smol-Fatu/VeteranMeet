import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  mode: "light",
  user: null,
  token: null,
  posts: [],
  events: [],
};

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    setLogin: (state, action) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
    },
    setFriends: (state, action) => {
      if (state.user) {
        state.user.friends = action.payload.friends;
      } else {
        console.error("user friends non-existent :(");
      }
    },
    setCommunityLogin: (state, action) =>
     {
      state.user = action.payload.user;
      state.token = action.payload.token;
    },
    setPosts: (state, action) => {
      state.posts = action.payload.posts;
    },
    setPost: (state, action) => {
      const updatedPosts = state.posts.map((post) => {
        if (post._id === action.payload.post._id) return action.payload.post;
        return post;
      });
      state.posts = updatedPosts;
    },
    setEvents: (state, action) => {
      state.events = action.payload.events;
    },
    setEvent: (state, action) => {
      const updatedPosts = state.posts.map((event) => 
      {
        if (event._id === action.payload.event._id) return action.payload.event;
        return event;
      });
      state.events = updatedPosts;
    },

  },
});

export const {  setLogin, setFriends,setCommunityLogin, setPosts, setPost , setEvents , setEvent } = authSlice.actions;
export default authSlice.reducer;
