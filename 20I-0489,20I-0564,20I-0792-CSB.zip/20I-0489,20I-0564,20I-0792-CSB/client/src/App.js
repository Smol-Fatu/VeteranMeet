import { BrowserRouter, Navigate, Routes, Route } from "react-router-dom";

import ProfilePage from "./Pages/Profile";
import { useMemo } from "react";
import { useSelector } from "react-redux";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { createTheme } from "@mui/material/styles";
import { themes } from "./theme";

import VeteranLogin from "./Pages/VeteranLogin"
import VeteranSignUp from "./Pages/VeteranSignUp"
import VereranDashBoard from "./Pages/VeteranDashboard"
import CommunitySignUp from "./Pages/CommunitySignup"
import CommunityLogin from "./Pages/CommunityLogin"
import CommunityDashboard from "./Pages/CommunityDashboard";

function App() {
  const mode = useSelector((state) => state.mode);
  const theme = useMemo(() => createTheme(themes(mode)), [mode]);
  const isAuth = Boolean(useSelector((state) => state.token));

  return (
    <div className="app">
      <BrowserRouter>
        <ThemeProvider theme={theme}>
          <CssBaseline />
          <Routes>
            
            <Route path="/" element={<CommunityLogin/>} />
            <Route path="/home" element={<VereranDashBoard/>}/>
            <Route path="/UserSignUp" element={<VeteranSignUp/>}/>
            <Route path="/UserSignIn" element={<VeteranLogin/>}/>
            <Route path="/OrganizationSignUp" element={<CommunitySignUp/>}/>
            <Route path="/OrganizationSignIn" element={<CommunityLogin/>}/>
          
            <Route path="/CommunityDashboard" element={<CommunityDashboard/>}/>
            <Route
              path="/profile/:userId"
              element={isAuth ? <ProfilePage /> : <Navigate to="/" />}
            />
          </Routes>
        </ThemeProvider>
      </BrowserRouter>
    </div>
  );
}

export default App;
