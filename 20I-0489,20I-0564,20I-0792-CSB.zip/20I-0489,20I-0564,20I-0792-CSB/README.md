# FullStack Social Media App
Complete React MERN Full Stack Social Media App


For users who are looking to contribute, I'm planning to possibly create a separate branch for community contributions and additional features as well as for improvements and fixes.

I haven't decided on the exact workflow I'll be using yet. But we'll get it out there soon!
