import Event from "../models/Events.js";
import User from "../models/User.js";


export const getFeedEvents = async (req, res) => 
{
  try {
    const EV = await Event.find();
    res.status(200).json(EV);
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
};

export const getEventPosts = async (req, res) => {
  try {
    const { userId } = req.params;
    const post = await Event.find({ userId });
    res.status(200).json(post);
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
};

export const InterestEvent = async (req, res) => {
  try {
    const { id } = req.params;
    const { userId } = req.body;
    const post = await Event.findById(id);
    const isLiked = Event.InterestEvent.get(userId);

    if (isLiked) {
      post.likes.delete(userId);
    } else {
      post.likes.set(userId, true);
    }

    const updatedPost = await Event.findByIdAndUpdate(
      id,
      { likes: post.InterestEvent },
      { new: true }
    );

    res.status(200).json(updatedPost);
  } catch (err) {
    res.status(404).json({ message: err.message });
  }
};
export const createEvent = async (req, res) => {
  try {
    const { userId, description, picturePath } = req.body;
    const user = await User.findById(userId);
    const newPost = new Event({
      userId,
      orgname: user.eventType,
      eventType,
      location: user.location,
      date,
      picturePath,
      userPicturePath: user.picturePath,
      Interest: {},
    });
    await newPost.save();

    const post = await Event.find();
    res.status(201).json(post);
  } catch (err) {
    res.status(409).json({ message: err.message });
  }
};
