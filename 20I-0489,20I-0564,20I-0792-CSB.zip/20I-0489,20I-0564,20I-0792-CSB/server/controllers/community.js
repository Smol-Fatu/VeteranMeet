import Community from "../models/Community";
import bcrypt from "bcrypt";


export const CreateCommunity = async (req, res) => {
    try {
      const { name , email , phone , type , password ,city} = req.body;
  
      const salt = await bcrypt.genSalt();
      const passwordHash = await bcrypt.hash(password, salt);
  
      const NewCommunity = new Community(
      {
        name,
        email,
        phone,
        type,
        password : passwordHash,
        city,
        firstName,
        lastName,
        email,
      });
      const savedUser = await NewCommunity.save();
      res.status(201).json(savedUser);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
};
