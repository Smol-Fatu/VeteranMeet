import express from "express";
import { ExtractVeteran } from "../Veteran_Functionality/ExtractVeteran.js";
import { GetVeteranFriends } from "../controllers/user.js";
import { AddRemoveFriend } from "../controllers/user.js";
import jwt from "jsonwebtoken";

const Middleware = async (req, res, next) => 
{
    let token = req.header("Authorization");
    if (!token) 
    {
        return res.status(403).send("Access Denied");
    }
    if (token.startsWith("Bearer ")) 
    {
        token = token.slice(7, token.length).trimLeft();
    }
    const verified = jwt.verify(token, process.env.JWT_SECRET);
    req.user = verified;
    next();
};

const VeteranRouter = express.Router();
VeteranRouter.get("/:id", Middleware, ExtractVeteran);
VeteranRouter.patch("/:id/:friendId", Middleware, AddRemoveFriend);
VeteranRouter.get("/:id/friends", Middleware , GetVeteranFriends);
export default VeteranRouter;
