import express from "express";
import { verifyToken } from "../middleware/auth.js";
import { getFeedEvents , getEventPosts , InterestEvent } from "../controllers/events.js";

const router = express.Router();
router.get("/", verifyToken, getFeedEvents);
router.get("/:userId/events", verifyToken, getEventPosts);
router.patch("/:id/like", verifyToken, InterestEvent);
export default router;
