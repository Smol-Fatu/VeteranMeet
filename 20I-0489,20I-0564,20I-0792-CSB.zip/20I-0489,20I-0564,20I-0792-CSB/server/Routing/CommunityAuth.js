import Community from "../models/Community.js";
import bcrypt from "bcrypt";
import express from "express";
import jwt from "jsonwebtoken";
const router = express.Router();

const CreateCommunity = async (req, res) => {
    try {
      const { name , email , password ,  type , phone , city} = req.body;
  
      const salt = await bcrypt.genSalt();
      const passwordHash = await bcrypt.hash(password, salt);
  
      const NewCommunity = new Community(
      {
        name,
        email,
        password : passwordHash,
        type,
        phone,
        city,
      });
      const savedUser = await NewCommunity.save();
      res.status(201).json(savedUser);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
};

router.post("/login", async (req, res) => 
{
    const { email, password } = req.body;
    const user = await Community.findOne({ email: email });
    if (!user) return res.status(400).json({ msg: "User does not exist. " });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ msg: "Invalid credentials. " });

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
    delete user.password;
    res.status(200).json({ token, user });
});

router.post("/RegisterCommunity" , CreateCommunity);

export default router;

