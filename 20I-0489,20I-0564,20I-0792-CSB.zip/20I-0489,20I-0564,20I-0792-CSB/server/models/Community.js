import mongoose from 'mongoose';

const CommunitySchema=new mongoose.Schema( 
{
    name:  { type: String, required: true },
    email: { type: String ,unique: true,required: true,lowercase: true },
    password: { type: String, required:  true, min: 8 },
    type:  { type: String, required:true },
    phone: { type: String, required:  true },
    city : {type:String}
})

const Community = mongoose.model( 'Community', CommunitySchema );
export default Community;
