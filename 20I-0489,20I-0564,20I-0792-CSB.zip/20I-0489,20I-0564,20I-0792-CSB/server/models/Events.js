import mongoose from "mongoose";

const EventSchema = mongoose.Schema(
  {
    userId : String,
    orgname: String,
    eventType : String,
    location: String,
    date : String,
    picturePath: String,
    userPicturePath: String,
    Interest: {
      type: Map,
      of: Boolean,
    },
  },
  { timestamps: true }
);

const Event = mongoose.model("Events", EventSchema);
export default Event;
