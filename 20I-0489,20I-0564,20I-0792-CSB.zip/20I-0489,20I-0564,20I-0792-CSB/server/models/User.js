import mongoose from "mongoose";
const VeteranSchema = new mongoose.Schema(
  {
    firstName:      { type: String, required: true , default: ""},
    lastName:       { type: String, required: true , default: "" },
    email:          { type: String, required: true , unique: true , default: ""},
    password:       { type: String, required: true , default: ""},
    picturePath:    { type: String , default: ""},
    friends:        { type: Array  , default: []},
    location:       { type: String , default: ""},
    occupation:     { type: String , default: ""},
    stars:  { type: Number, default: ""},
  },
  { timestamps: true }
);
VeteranSchema.virtual( 'Stars' ).get( function () 
{
    if      ( this.stars>=25000 ) { return 'Silver Veteran' }
    else if ( this.stars>=40000 ) { return "Ruby Veteran" }
    else if ( this.stars>=50000 ) { return "Golden Veteran" }
    else if ( this.stars>=60000 ) { return "Diamond Veteran" }
    else if ( this.stars>=65000 ) { return "Sapphire Veteran" }
    else if ( this.stars>=70000 ) { return "Platinum Veteran" }
    else if ( this.stars>=100000 ) { return "Eternal Veteran" }
});

const Veteran = mongoose.model("Veteran", VeteranSchema);
export default Veteran;
