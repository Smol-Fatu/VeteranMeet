import Veteran from "../models/User";
export const GetVeteranFriends = async (Request,Response) => 
{
    const { id } = Request.params;
    const user = await Veteran.findById(id);
    const friends = await Promise.all( user.friends.map((id) => Veteran.findById(id)));
    const ListOfFriends = friends.map(({ _id, firstName, lastName, occupation, location, picturePath }) => {
        return { _id, firstName, lastName, occupation, location, picturePath };}
    );
    Response.status(200).json(ListOfFriends);
};

export default GetVeteranFriends;