import Veteran from "../models/User.js";

export const ExtractVeteran = async (Request, Response) => 
{
    const { id } = Request.params;
    const user = await Veteran.findById(id);
    Response.status(200).json(user);
};

export default ExtractVeteran;